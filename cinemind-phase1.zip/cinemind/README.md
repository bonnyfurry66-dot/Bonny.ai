# CineMind AI

Secure AI video-generation studio. **Status: Phase 1 (architecture scaffold).**

## Setup
```bash
cp .env.example .env      # fill in values; generate SESSION_SECRET: openssl rand -base64 48
docker compose up -d      # Postgres + Redis
npm install
npm run dev               # http://localhost:3000, health at /api/health
npm run typecheck && npm test
```

## Phase 1 scope
Project structure, dependency config, env validation, provider interface, service contracts, security headers.

## Not yet implemented
Auth, database models (Phase 2), prompt enhancer (3), provider adapter + jobs (4), storage/FFmpeg/exports (5), quotas/tests (6), deployment (7).

## External services required later
Video provider account + API key (chosen in Phase 4 after verifying official docs), LLM API key, S3-compatible private storage.
