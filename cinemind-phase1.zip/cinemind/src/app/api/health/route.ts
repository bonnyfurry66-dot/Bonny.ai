import { NextResponse } from "next/server";
import { getEnv, providerConfigured } from "@/lib/env";

export async function GET() {
  try {
    const env = getEnv();
    return NextResponse.json({ ok: true, providerConfigured: providerConfigured(env), generationEnabled: env.GENERATION_ENABLED === "true" });
  } catch {
    return NextResponse.json({ ok: false, error: "Configuration invalid" }, { status: 500 });
  }
}
