import type { ReactNode } from "react";
import "./globals.css";

export const metadata = { title: "CineMind AI", description: "AI filmmaking studio" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
