export default function Landing() {
  return (
    <main className="mx-auto max-w-3xl p-6">
      <h1 className="text-3xl font-semibold">CineMind AI</h1>
      <p className="mt-3 text-neutral-300">
        Turn an idea into a multi-scene video project using a configurable AI video provider.
        Results depend on the provider and model; character consistency is not guaranteed.
      </p>
    </main>
  );
}
