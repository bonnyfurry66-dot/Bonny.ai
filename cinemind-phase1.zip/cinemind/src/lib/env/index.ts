import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  APP_URL: z.string().url(),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  SESSION_SECRET: z.string().min(32),
  GENERATION_ENABLED: z.enum(["true", "false"]).default("false"),
  MAX_CONCURRENT_JOBS_PER_USER: z.coerce.number().int().min(1).max(20).default(2),
  VIDEO_PROVIDER: z.string().optional(),
  VIDEO_PROVIDER_API_KEY: z.string().optional(),
  VIDEO_PROVIDER_WEBHOOK_SECRET: z.string().optional()
});

export type Env = z.infer<typeof schema>;

/** Server-only. Throws a safe error naming invalid keys, never their values. */
export function getEnv(): Env {
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const keys = parsed.error.issues.map((i) => i.path.join(".")).join(", ");
    throw new Error(`Invalid environment configuration: ${keys}. See .env.example.`);
  }
  return parsed.data;
}

/** Whether the video provider is configured; the app still runs without it. */
export function providerConfigured(env: Env = getEnv()): boolean {
  return Boolean(env.VIDEO_PROVIDER && env.VIDEO_PROVIDER_API_KEY);
}
