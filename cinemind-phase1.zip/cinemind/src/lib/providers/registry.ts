import { getEnv, providerConfigured } from "@/lib/env";
import type { VideoProvider } from "./types";

// Adapters are registered in Phase 4 after verifying the provider's official docs.
const adapters: Record<string, () => VideoProvider> = {};

export class ProviderNotConfiguredError extends Error {
  constructor() {
    super("No video provider configured. Set VIDEO_PROVIDER and VIDEO_PROVIDER_API_KEY (see README).");
  }
}

export function getVideoProvider(): VideoProvider {
  const env = getEnv();
  if (!providerConfigured(env)) throw new ProviderNotConfiguredError();
  const factory = adapters[env.VIDEO_PROVIDER as string];
  if (!factory) throw new ProviderNotConfiguredError();
  return factory();
}
