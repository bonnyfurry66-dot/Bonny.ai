import { z } from "zod";

export const GenerationState = z.enum([
  "QUEUED", "VALIDATING", "GENERATING", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"
]);
export type GenerationState = z.infer<typeof GenerationState>;

export const GenerationRequest = z.object({
  prompt: z.string().min(1).max(4000),
  negativePrompt: z.string().max(1000).optional(),
  durationSeconds: z.number().int().positive(),
  aspectRatio: z.string(),
  resolution: z.string(),
  referenceImageKey: z.string().optional(),
  lastFrameImageKey: z.string().optional(),
  idempotencyKey: z.string().min(16).max(128)
});
export type GenerationRequest = z.infer<typeof GenerationRequest>;

export interface ProviderCapabilities {
  textToVideo: boolean;
  imageToVideo: boolean;
  lastFrame: boolean;
  cancellation: boolean;
  webhooks: boolean;
  progressReporting: boolean;
  durationsSeconds: number[];
  aspectRatios: string[];
  resolutions: string[];
}

export interface ProviderStatus {
  state: GenerationState;
  progressPercent?: number;
  error?: string;
}

export interface CostEstimate {
  available: boolean;
  amountUsd?: number;
  note: string; // must explain when unavailable; never invent prices
}

/** Adapters implement only what the real provider supports. */
export interface VideoProvider {
  readonly id: string;
  capabilities(): ProviderCapabilities;
  estimateCost(req: GenerationRequest): CostEstimate;
  submit(req: GenerationRequest): Promise<{ providerJobId: string }>;
  getStatus(providerJobId: string): Promise<ProviderStatus>;
  retrieve(providerJobId: string): Promise<{ downloadUrl: string }>;
  cancel?(providerJobId: string): Promise<void>;
  verifyWebhook?(rawBody: string, headers: Headers): boolean;
}
