import type { GenerationRequest, CostEstimate, GenerationState } from "@/lib/providers/types";

/** Contracts for Phases 2-5. Implementations land in their modules. */
export interface GenerationServices {
  validateGenerationRequest(userId: string, input: unknown): Promise<GenerationRequest>;
  enhanceVideoPrompt(userId: string, idea: string): Promise<unknown>; // ScenePlan in Phase 3
  estimateGenerationCost(req: GenerationRequest): CostEstimate;
  submitVideoGeneration(userId: string, projectId: string, req: GenerationRequest): Promise<{ jobId: string }>;
  getGenerationStatus(userId: string, jobId: string): Promise<{ state: GenerationState; progressPercent?: number }>;
  retrieveGeneratedVideo(userId: string, jobId: string): Promise<{ assetId: string }>;
  cancelGeneration(userId: string, jobId: string): Promise<void>;
  processGeneratedAssets(jobId: string): Promise<void>;
  authorizeProjectAccess(userId: string, projectId: string): Promise<void>; // throws if denied
  deleteProjectAndAssets(userId: string, projectId: string): Promise<void>;
}
