import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: { ink: "#0b0c10", panel: "#14161d", accent: "#e5a93d" } } },
  plugins: []
} satisfies Config;
