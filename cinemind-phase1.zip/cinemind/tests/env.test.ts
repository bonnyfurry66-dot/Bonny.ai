import { describe, it, expect } from "vitest";
import { getEnv } from "../src/lib/env";

describe("env validation", () => {
  it("rejects a short session secret without leaking its value", () => {
    Object.assign(process.env, {
      APP_URL: "http://localhost:3000", DATABASE_URL: "x", REDIS_URL: "y", SESSION_SECRET: "short-secret-value"
    });
    let message = "";
    try { getEnv(); } catch (e) { message = (e as Error).message; }
    expect(message).toContain("SESSION_SECRET");
    expect(message).not.toContain("short-secret-value");
  });
});
