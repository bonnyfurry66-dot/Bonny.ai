// Phase 4 adds BullMQ workers (generation polling, FFmpeg). Placeholder so `npm run worker` resolves.
console.log("CineMind worker: no queues registered yet (Phase 4).");
